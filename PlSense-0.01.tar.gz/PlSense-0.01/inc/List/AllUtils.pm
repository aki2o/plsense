#line 1
package List::AllUtils;
{
  $List::AllUtils::VERSION = '0.03';
}

use strict;
use warnings;

# List::Util does not define an :all tag
BEGIN
{
    require List::Util;
    List::Util->import( @List::Util::EXPORT_OK );
}
use List::MoreUtils 0.28 qw( :all );

use base 'Exporter';

our @EXPORT_OK = ( @List::Util::EXPORT_OK, @List::MoreUtils::EXPORT_OK );

our %EXPORT_TAGS = ( all => \@EXPORT_OK );


1;

# ABSTRACT: Combines List::Util and List::MoreUtils in one bite-sized package



#line 509


__END__

