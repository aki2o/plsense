#!/usr/bin/perl

use FindBin;
use List::AllUtils qw{ min max };


# astart import scalar
#$
# aend include: FindBin::Bin

# astart import method
#m
# aend include: map min max
# ahelp max : ^ max \s is \s Method \s of \s List::AllUtils\. $
# ahelp max : ^ Return: \s
# ahelp max : ^ \s* max \s+ LIST \s

