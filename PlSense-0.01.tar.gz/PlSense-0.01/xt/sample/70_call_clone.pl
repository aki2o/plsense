#!/usr/bin/perl

use lib "lib";
use ClassStdClone;

my $cl = ClassStdClone->new();
my $cc = $cl->clone;


# astart resolve clone
#$cc->
# aend equal: can clmtd clone isa

