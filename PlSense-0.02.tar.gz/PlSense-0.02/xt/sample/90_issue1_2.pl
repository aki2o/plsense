#!/usr/bin/perl

use vars ('$fuga', '@bar');

# astart use vars by brace has multiple 1
#$
# aend include: fuga bar

# astart use vars by brace has multiple 2
#@
# aend include: bar

