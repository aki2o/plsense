#!/usr/bin/perl

for my $idx ( 0..10 ) {
    # astart for var 1
    #$
    # aend include: idx
}

for ( my $count = 0; $count <= 10; $count++ ) {
    # astart for var 2
    #$
    # aend include: count
}

foreach my $currword ( "hoge", "fuga" ) {
    # astart foreach var
    #$
    # aend include: currword
}

while ( my $line = <> ) {
    # astart while var
    #$
    # aend include: line
}

